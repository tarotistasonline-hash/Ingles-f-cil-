import React, { useState, useEffect } from 'react';
import { Sun, Moon, Download, FileCode, CheckCircle2, X, Sparkles, Globe, ShieldCheck } from 'lucide-react';
import { RealVisitsBadge } from './RealVisitsBadge';
import { isCreatorMode, subscribeToVisitorUpdates } from '../services/visitorTracker';
import { AppTheme } from '../types';

interface FooterProps {
  onNavigate: (tab: string) => void;
  currentTheme?: AppTheme;
  onToggleTheme?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  currentTheme = 'vibrant-dark',
  onToggleTheme,
}) => {
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [isCreator, setIsCreator] = useState(() => isCreatorMode());

  useEffect(() => {
    return subscribeToVisitorUpdates((stats) => {
      setIsCreator(stats.isCreator);
    });
  }, []);
  return (
    <footer className="bg-[#070D18] text-slate-400 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
          <div className="space-y-1 text-center md:text-left">
            <span className="font-heading text-xl font-bold text-white tracking-tight">
              Inglés Fácil y Fluido
            </span>
            <p className="text-xs text-slate-400 max-w-sm">
              Una forma sencilla de aprender el idioma: fluidez natural, bloques de conversación real y cero recetas gramaticales rígidas.
            </p>
          </div>

          <nav className="flex flex-wrap items-center justify-center gap-6 text-xs font-medium text-slate-400">
            <button
              onClick={() => onNavigate('entrecasa')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Vida Cotidiana
            </button>
            <button
              onClick={() => onNavigate('simulator')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Simulador de Voz
            </button>
            <button
              onClick={() => onNavigate('method')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Método Sin Reglas
            </button>
            <button
              onClick={() => onNavigate('tweak')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Habla Coloquial
            </button>
            <button
              onClick={() => onNavigate('chunks')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Bloques de Poder
            </button>
            <button
              onClick={() => onNavigate('gym')}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Reflejos en 5s
            </button>
            <button
              onClick={() => onNavigate('blog')}
              className="hover:text-amber-400 transition-colors cursor-pointer text-amber-300 font-medium"
            >
              💬 Blog & Sugerencias
            </button>
            <button
              onClick={() => onNavigate('kit')}
              className="hover:text-emerald-300 transition-colors cursor-pointer text-emerald-400 font-medium"
            >
              🎧 Audio-Kit de Bolsillo
            </button>
          </nav>
        </div>

        {/* Real Visits Counter with Creator Exclusion */}
        <div className="py-6 border-b border-slate-800/80">
          <RealVisitsBadge />
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} VibeEnglish. Aprende a hablar con libertad.</p>
          
          <div className="flex flex-wrap items-center gap-3">
            {onToggleTheme && (
              <button
                type="button"
                onClick={onToggleTheme}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 hover:border-amber-400/40 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs"
                title="Cambiar entre modo Oscuro (Vibrant Dark) y modo Claro (Clean Light)"
              >
                {currentTheme === 'clean-light' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Cambiar a Modo Oscuro</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>Cambiar a Modo Claro (Alto Contraste)</span>
                  </>
                )}
              </button>
            )}

            {isCreator && (
              <button
                type="button"
                onClick={() => setShowBackupModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/40 text-amber-300 hover:text-white transition-all cursor-pointer text-xs font-bold"
                title="Panel de Creador: Descargar código fuente y archivos listos para subir a Netlify"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Backup & Código Fuente (Solo Creador)</span>
              </button>
            )}

            <span aria-hidden="true">·</span>
            <span>Audio adaptable para principiantes</span>
          </div>
        </div>
      </div>

      {/* Backup & Netlify Restore Modal */}
      {showBackupModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
          onClick={() => setShowBackupModal(false)}
        >
          <div
            className="bg-[#120D2C] border-2 border-amber-400/50 rounded-2xl max-w-lg w-full p-6 text-slate-200 shadow-2xl relative space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-300">
                  <FileCode className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    Código Fuente y Restauración Netlify
                  </h3>
                  <p className="text-xs text-slate-400">
                    Descarga tu proyecto completo para dar a soporte o restaurar tu web
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowBackupModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Option 1: Full Source Code */}
              <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <FileCode className="w-4 h-4 text-emerald-400" />
                    <span>1. Código Fuente Completo (.ZIP)</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">6.8 MB</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Contiene todo el proyecto (React, TypeScript, componentes, audios, estilos y backend). Es el archivo que te pidió el soporte de Netlify.
                </p>
                <a
                  href="/codigo_fuente_completo.zip"
                  download="codigo_fuente_completo.zip"
                  className="w-full py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-400/20"
                >
                  <Download className="w-4 h-4" />
                  <span>Descargar Código Fuente (.ZIP)</span>
                </a>
              </div>

              {/* Option 2: Pre-compiled Netlify Deploy Folder */}
              <div className="p-4 rounded-xl bg-black/50 border border-amber-400/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Globe className="w-4 h-4 text-amber-400" />
                    <span>2. Web Lista para Netlify (.ZIP)</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">7.1 MB</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Sitio web ya compilado con el archivo <strong className="text-white font-mono">_redirects</strong> preinstalado (evita que la pantalla quede en blanco o vacía al recargar en Netlify).
                </p>
                <a
                  href="/sitio_listo_netlify_dist.zip"
                  download="sitio_listo_netlify_dist.zip"
                  className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-400/20"
                >
                  <Download className="w-4 h-4" />
                  <span>Descargar Sitio Listo para Netlify (.ZIP)</span>
                </a>
              </div>
            </div>

            {/* Quick Netlify Instructions */}
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 text-[11px] text-slate-300 space-y-1">
              <span className="font-bold text-amber-300 block">¿Cómo restaurar tu dominio en Netlify en 30 segundos?</span>
              <ol className="list-decimal list-inside space-y-0.5 text-slate-400">
                <li>Descomprime el archivo <strong>sitio_listo_netlify_dist.zip</strong>.</li>
                <li>Entra a tu panel de Netlify en tu dominio.</li>
                <li>Ve a la pestaña <strong>Deploys</strong> y arrastra la carpeta descompromida al recuadro de subida.</li>
                <li>¡Listo! Tu sitio y tu dominio .org volverán a estar activos de inmediato.</li>
              </ol>
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={() => setShowBackupModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};
